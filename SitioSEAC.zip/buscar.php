<?php
include 'includes/templates/header.php';
?>

<!-- <div style="margin-top: 10rem;">
    <script async src="https://cse.google.com/cse.js?cx=673c65ab4f9ec44fc">
    </script>
    <div class="gcse-searchresults-only"></div>
</div> -->

<?php
include 'includes/templates/footer.php';
?>